"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_sqs_1 = require("@aws-sdk/client-sqs");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const util_dynamodb_1 = require("@aws-sdk/util-dynamodb");
const moment_timezone_1 = __importDefault(require("moment-timezone"));
const dynamoDBClient = new client_dynamodb_1.DynamoDBClient({ region: "us-east-1" });
const ddbDocClient = lib_dynamodb_1.DynamoDBDocumentClient.from(dynamoDBClient);
const sqs = new client_sqs_1.SQSClient({ region: "us-east-1" });
const handler = async (event) => {
    var _a, _b, _c, _d;
    const inputData = event.body;
    console.info("Body: ", inputData);
    const ordenCompraProcessed = [];
    try {
        const query = {
            TableName: "DynamoDb-Orden-Compra",
            FilterExpression: "#nested.#attribute.#subAttribute = :value",
            ExpressionAttributeNames: {
                "#nested": "stages",
                "#attribute": "domiciliosProcessFailed",
                "#subAttribute": "success"
            },
            ExpressionAttributeValues: {
                ":value": { "BOOL": true }
            }
        };
        const command = new client_dynamodb_1.ScanCommand(query);
        const qeueryResult = await dynamoDBClient.send(command);
        console.info("Length data result: ", (_a = qeueryResult.Items) === null || _a === void 0 ? void 0 : _a.length);
        for (const item of qeueryResult.Items || []) {
            const itemJson = (0, util_dynamodb_1.unmarshall)(item);
            console.info(`Reprocess Orden Compra ID: ${itemJson.ordenCompraId}`);
            console.info(`Orden Compra details: ${JSON.stringify(itemJson)}`);
            try {
                const timezone = 'America/Bogota';
                const currentTime = (0, moment_timezone_1.default)().tz(timezone).format();
                const stages = (_b = item.stages) === null || _b === void 0 ? void 0 : _b.M;
                const putInSqsDomicilios = (_c = stages === null || stages === void 0 ? void 0 : stages.putInSqsDomicilios) === null || _c === void 0 ? void 0 : _c.M;
                const attempsPutInSqsDomicilios = Number((_d = putInSqsDomicilios === null || putInSqsDomicilios === void 0 ? void 0 : putInSqsDomicilios.attempts) === null || _d === void 0 ? void 0 : _d.N);
                const attempProcessed = attempsPutInSqsDomicilios + 1;
                const itemToUpdate = {
                    TableName: "DynamoDb-Orden-Compra",
                    Key: { ordenCompraId: itemJson.ordenCompraId },
                    UpdateExpression: "SET stages.putInSqsDomicilios.attempts = :attemptsPutInSqsDomicilios, stages.putInSqsDomicilios.success = :successPutInSqsDomicilios, stages.putInSqsDomicilios.updatedAt = :updatedAtputInSqsDomicilios, stages.domiciliosProcessFailed.success = :successDomiciliosProcessFailed, stages.domiciliosProcessFailed.updatedAt = :updatedAtDomiciliosProcessFailed, mockDLQ.process = :mockDLQProcess, updatedAt = :updatedAt",
                    ExpressionAttributeValues: {
                        ":attemptsPutInSqsDomicilios": attempProcessed,
                        ":successPutInSqsDomicilios": true,
                        ":updatedAtputInSqsDomicilios": currentTime.toString(),
                        ":successDomiciliosProcessFailed": false,
                        ":updatedAtDomiciliosProcessFailed": currentTime.toString(),
                        ":mockDLQProcess": inputData.mockDLQ.process,
                        ":updatedAt": currentTime.toString(),
                    },
                };
                await ddbDocClient.send(new lib_dynamodb_1.UpdateCommand(itemToUpdate));
                console.info(`Orden Compra ID: ${itemJson.ordenCompraId} Updated in DynamoDB - attemps: ${attempProcessed}`);
                try {
                    const params = {
                        QueueUrl: "https://sqs.us-east-1.amazonaws.com/211125768545/Sqs-Domicilios",
                        MessageBody: JSON.stringify({
                            ordenCompraId: itemJson.ordenCompraId,
                            data: {
                                productos: itemJson.productos,
                                cliente: itemJson.cliente,
                                valorTotalPagar: itemJson.valorTotalPagar,
                                mockDLQ: inputData.mockDLQ
                            }
                        }),
                    };
                    const dataSqsSent = await sqs.send(new client_sqs_1.SendMessageCommand(params));
                    ordenCompraProcessed.push({ ...dataSqsSent.$metadata, MessageId: dataSqsSent.MessageId });
                    console.info(`Orden Compra ID: ${itemJson.ordenCompraId} sent to SQS Domicilios`);
                }
                catch (errSqs) {
                    console.error("Error", errSqs);
                    throw new Error(`Error pushing to SQS Domicilios - Orden Compra ID: ${itemJson.ordenCompraId}`);
                }
            }
            catch (errUpdatingDynamoDb) {
                console.error("Error updating record", item, errUpdatingDynamoDb);
                throw new Error(`Errors occurred updating records: ${errUpdatingDynamoDb}`);
            }
        }
        return {
            statusCode: 500,
            body: ordenCompraProcessed
        };
    }
    catch (errQueryDynamoDB) {
        console.error("Error query record", errQueryDynamoDB);
        throw new Error(`Errors occurred query records: ${errQueryDynamoDB}`);
    }
};
exports.handler = handler;
